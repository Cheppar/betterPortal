<?php include "includes/init.php" ?>
<?php
    if ($_GET['user']) {
        if ($_GET['code']) {
            $username=$_GET['user'];
            $vcode=$_GET['code'];
            if (count_field_val($pdo, "users", "username", $username)>0) {
                $row=return_field_data($pdo, "users", "username", $username);
                if ($vcode!=$row['validationcode']) {
                    set_msg("Validation code does not match database");
                    redirect("index.php");
                }
            } else {
                set_msg("User '{$username}' not found in database");
                redirect("index.php");
            }
        } else {
            set_msg("No validation code included with reset request");
            redirect("index.php");
        }
    } else {
        set_msg("No user included with reset request");
        redirect("index.php");
    }
    if ($_SERVER['REQUEST_METHOD']=="POST") {
        try {
            $password=$_POST['password'];
            $pword_confirm=$_POST['password_confirm'];
            if ($password==$pword_confirm) {
                $stmnt=$pdo->prepare("UPDATE users SET password=:password WHERE username=:username");
                $user_data=[':password'=>password_hash($password, PASSWORD_BCRYPT), ':username'=>$username];
                $stmnt->execute($user_data);
                set_msg("Password successfully updated. Please log in");
                redirect("login.php");
            } else {
                set_msg("Passwords don't match");
            }
        } catch(PDOException $e) {
            echo "Error: ".$e->getMessage();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <?php include "includes/header.php" ?> 
    <body>
      <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
          <span class='sr-only'>Loading...</span>
        </div>
      </div>

        <div class="page-container">


          <div class="page-header">

          <!-- NAV START -->
            <?php include "../includes/nav.php" ?> 
         <!-- NAV END -->
            
        </div>

<!-- HEADER END -->

  <!-- SIDEBAR START -->
            
      <?php include "../includes/sidebar.php" ?> 

    <!-- SIDEBAR END -->

    <!-- PAGE CONTENT START -->

            <div class="page-content">
                <div class="main-wrapper">
                    <div class="row">

     <div class="row justify-content-md-center">
                <div class="col-md-12 col-lg-4">

                    <div class="card login-box-container">
                        <div class="card-body">

                    <?php
                        if (isset($error)) {
                            foreach ($error as $msg) {
                                echo "<h4 class='bg-danger text-center'>{$msg}</h4>";
                            }
                        } ?>

                        <?php 
                        show_msg();
                    ?>
                            <div class="authent-logo">
                                <img src="../../assets/images/logo@2x.png" alt="">
                            </div>

                            <div class="authent-text">
                                <h2>New Password</h2>
                                <p>Keep it private</p>
                            </div>

                            <form id="login-form" method="post" role="form">  
                                
                                <div class="mb-3">
                                    <div class="form-floating">
                                          <input type="password" name="password" id="password" tabindex="1" class="form-control" placeholder="Password"  required>
                                        <label for="password">Password</label>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                          <input type="password" name="password_confirm" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirm Password" required>
                                        <label for="password_confirm">Password Confirmation</label>
                                    </div>
                                </div>

                                <div class="d-grid">
                                      <input type="submit" name="reset-submit" id="reset-submit" tabindex="4" class="form-control btn btn-success" value="Reset Password">
                                </div>

                            </form>
                              
                        </div>
                    </div>
                </div>
            </div>
                                  
                </div>


                <!-- PAGE CONTENT END -->
              
            </div>
        
        <!-- Javascripts -->
        <?php include "includes/footer.php" ?> 
    </body>
</html>
