
<?php include "includes/init.php" ?>

<?php
    if ($_SERVER['REQUEST_METHOD']=="POST") {
        $fname = $_POST['firstname'];
        $lname = $_POST['lastname'];
        $uname = $_POST['username'];
        $email = $_POST['email'];
        $email_conf = $_POST['email_confirm'];
        $pword = $_POST['password'];
        $pword_conf = $_POST['password_confirm'];
        $comments = $_POST['comments'];
        
        if (strlen($lname)<3) {
            $error[] = "Last name must be at least 3 charachters long";
        }
        if (strlen($uname)<6) {
            $error[] = "User name must be at least 6 charachters long";
        }
        if (strlen($pword)<6) {
            $error[] = "Password must be at least 6 charachters long";
        }
        if ($pword != $pword_conf) {
            $error[] = "Passwords do not match";
        }
        if ($email != $email_conf) {
            $error[] = "Email addresses do not match";
        }
        if (count_field_val($pdo, "users", "username", $uname)!=0) {
            $error[] = "Username '{$uname}' already exists";
        }
        if (count_field_val($pdo, "users", "email", $email)!=0) {
            $error[] = "Email '{$email}' already exists";
        }
        
        if (!isset($error)) {
            $vcode=generate_token();
            try {
                $sql = "INSERT INTO users (firstname, lastname, username, email, password, comments, validationcode, active, joined, last_login) VALUES (:firstname, :lastname, :username, :email, :password, :comments, :vcode, 0, current_date, current_date)";
                $stmnt = $pdo->prepare($sql);
                $user_data = [':firstname'=>$fname, ':lastname'=>$lname, ':username'=>$uname, ':email'=>$email, ':password'=>password_hash($pword, PASSWORD_BCRYPT), ':comments'=>$comments, ':vcode'=>$vcode];
                $stmnt->execute($user_data);
                
                $body = "Please go to http://{$_SERVER['SERVER_NAME']}/{$root_directory}/activate.php?user={$uname}&code={$vcode} in order to activate account";
                send_mail($email, "Activate User", $body, $from_email, $reply_email);
            } catch(PDOException $e) {
                echo "Error: ".$e->getMessage();
            }
        }
        
    } else {
        $fname="";
        $lname="";
        $uname="";
        $email="";
        $email_conf="";
        $pword="";
        $pword_conf="";
        $comments="";
    }
?> 

<!DOCTYPE html>
<html lang="en">

    <?php include "includes/header.php" ?> 
    
    <body>
      <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
          <span class='sr-only'>Loading...</span>
        </div>
      </div>

        <div class="page-container">


          <div class="page-header">

          <!-- NAV START -->
            <?php include "../includes/nav.php" ?> 
         <!-- NAV END -->
            
        </div>

<!-- HEADER END -->

  <!-- SIDEBAR START -->
            
      <?php include "../includes/sidebar.php" ?> 

    <!-- SIDEBAR END -->

    <!-- PAGE CONTENT START -->

            <div class="page-content">
                <div class="main-wrapper">
                    <div class="row">

     <div class="row justify-content-md-center">
                <div class="col-md-12 col-lg-4">

                    <div class="card login-box-container">
                        <div class="card-body">

                    <?php
                        if (isset($error)) {
                            foreach ($error as $msg) {
                                echo "<h4 class='bg-danger text-center'>{$msg}</h4>";
                            }
                        } ?>

                        <?php 
                        show_msg();
                    ?>
                            <div class="authent-logo">
                                <img src="../../assets/images/logo@2x.png" alt="">
                            </div>

                            <div class="authent-text">
                                <h2>Register</h2>
                                <p>Ensure you have </p>
                            </div>

                            <form id="register-form" method="post" role="form">
                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="text" name="firstname" id="firstname" tabindex="1" class="form-control"  placeholder="First name" value='<?php echo $fname ?>' required >
                                        <label for="firstname">First name</label>
                                      </div>
                                </div>

                                 <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="text" name="lastname" id="lastname" tabindex="2" class="form-control"  placeholder="Last name" value='<?php echo $lname ?>' required >
                                        <label for="lastname">Last name</label>
                                      </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="text" name="username" id="username" tabindex="3" class="form-control"  placeholder="Username" value='<?php echo $uname ?>' required >
                                        <label for="username">Username</label>
                                      </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="email" name="email" id="register_email" tabindex="4" class="form-control"  placeholder="Email Address" value='<?php echo $email ?>' required >
                                        <label for="email">Email Address</label>
                                      </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="email" name="email_confirm" id="confirm_email" tabindex="5" class="form-control"  placeholder="Confirm Email Address" value='<?php echo $email_conf ?>' required >
                                        <label for="confirm_email">Confirm Email Address</label>
                                      </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="password" name="password" id="password" tabindex="6" class="form-control" placeholder="Password" value = "<?php echo $pword ?>" required>
                                        <label for="password">Password</label>
                                      </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="password" name="password_confirm" id="confirm-password" tabindex="7" class="form-control" placeholder="Confirm Password" value = "<?php echo $pword_conf ?>" required>
                                        <label for="floatingPassword">Confirm Password</label>
                                      </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <textarea name="comments" id="comments" tabindex="8" class="form-control"  placeholder="Comments"><?php echo $comments ?></textarea>
                                        <label for="comments">Comments</label>
                                      </div>
                                </div>


                                <!-- <div class="mb-3 form-check">
                                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                  <label class="form-check-label" for="exampleCheck1">I agree the <a href="#">Terms and Conditions</a></label>
                                </div> -->
                                <div class="d-grid">
                                <button type="submit" class="btn btn-primary m-b-xs">Register</button>
                            </div>
                              </form>
                            </form>
                              
                        </div>
                    </div>
                </div>
            </div>
                                  
                </div>


                <!-- PAGE CONTENT END -->
              
            </div>
        
        <!-- Javascripts -->
        <?php include "includes/footer.php" ?> 
    </body>
</html>
