<?php include "includes/init.php"; ?>
<?php
    if ($_SERVER['REQUEST_METHOD']=='POST') {
        $username=$_POST['username'];
        if (count_field_val($pdo, "users", "username", $username)>0) {
            $row=return_field_data($pdo, "users", "username", $username);
            $body = "Please go to http://{$_SERVER['SERVER_NAME']}/{$root_directory}/reset_2.php?user={$username}&code={$row['validationcode']} in order to reset your password";
            send_mail($row['email'], "Reset Password", $body, $from_email, $reply_email);
        } else {
            set_msg("User '{$username}' was not found in the database");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <?php include "includes/header.php" ?> 
    <body>
      <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
          <span class='sr-only'>Loading...</span>
        </div>
      </div>

        <div class="page-container">


          <div class="page-header">

          <!-- NAV START -->
            <?php include "../includes/nav.php" ?> 
         <!-- NAV END -->
            
        </div>

<!-- HEADER END -->

  <!-- SIDEBAR START -->
            
      <?php include "../includes/sidebar.php" ?> 

    <!-- SIDEBAR END -->

    <!-- PAGE CONTENT START -->

            <div class="page-content">
                <div class="main-wrapper">
                    <div class="row">

     <div class="row justify-content-md-center">
                <div class="col-md-12 col-lg-4">

                    <div class="card login-box-container">
                        <div class="card-body">

                    <?php
                        if (isset($error)) {
                            foreach ($error as $msg) {
                                echo "<h4 class='bg-danger text-center'>{$msg}</h4>";
                            }
                        } ?>


                        <?php 
                        show_msg();
                    ?>
                            <div class="authent-logo">
                                <img src="../../assets/images/logo@2x.png" alt="">
                            </div>

                            <div class="authent-text">
                                <h2>Password Reset</h2>
                                <p>Reset your password</p>
                            </div>

                            <form id="login-form" method="post" role="form">  
                                
                                <div class="mb-3">
                                    <div class="form-floating">
                                          <input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username"  required>
                                        <label for="username">Username</label>
                                    </div>
                                </div>

                                <div class="d-grid">
                                     <input type="submit" name="reset-submit" id="reset-submit" tabindex="4" class="form-control btn btn-success" value="Reset password">
                                </div>

                            </form>
                              
                        </div>
                    </div>
                </div>
            </div>
                                  
                </div>


                <!-- PAGE CONTENT END -->
              
            </div>
        
        <!-- Javascripts -->
        <?php include "includes/footer.php" ?> 
    </body>
</html>