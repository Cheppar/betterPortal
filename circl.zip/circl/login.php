<?php include "includes/init.php" ?>
<?php
    if ($_SERVER['REQUEST_METHOD']=='POST') {
        $username=$_POST['username'];
        $password=$_POST['password'];
        if (isset($_POST['remember'])) {
            $remember = "on";
        } else {
            $remember = "off";
        }
        if (count_field_val($pdo, "users", "username", $username)>0) {
            $user_data = return_field_data($pdo, "users", "username", $username);
            if ($user_data['active']==1) {
                if (password_verify($password, $user_data['password'])) {
                    set_msg("Logged in successfully", "success");
                    update_login_date($pdo, $username);
                    $_SESSION['username']=$username;
                    if ($remember="on") {
                        setcookie("username", $username, time()+86400);
                    }
                    redirect("mycontent.php");
                } else {
                    set_msg("Password is invalid");
                }
            } else {
                set_msg("User '{$username}' found but has not been activated");
            }
        } else {
            set_msg("User '{$username}' does not exist");
        }
    } else {
        $username="";
        $password="";
    }
?>

<!DOCTYPE html>
<html lang="en">
    
    <?php include "includes/header.php" ?>
    

    <body class="login-page">


        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
              <span class='sr-only'>Loading...</span>
            </div>
          </div>
        <div class="container">


            <div class="row justify-content-md-center">
                <div class="col-md-12 col-lg-4">

                     <?php 
                        show_msg();
                    ?>
                    
                    <div class="card login-box-container">
                        <div class="card-body">
                            <div class="authent-logo">
                                <img src="../assets/images/logo@2x.png" alt="">
                            </div>
                            <div class="authent-text">
                                <p>Welcome</p>
                                <p>Please Sign-in to your account.</p>
                            </div>

                            <form>
                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="text" name="username" id="username" tabindex="1" class="form-control"  placeholder="username" value='<?php echo $username; ?>' required>
                                        <label for="floatingInput">Username</label>
                                      </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="password"  name="password" id="login-password" tabindex="2" class="form-control" placeholder="Password" value= '<?php echo $password; ?>' required>
                                        <label for="login-password">Password</label>
                                      </div>
                                </div>

                                <div class="mb-3 form-check">
                                  <input type="checkbox" tabindex="3" name="remember" id="remember">
                                  <label class="form-check-label" for="remember">Stay logged in</label>
                                </div>

                                <div class="d-grid">
                                <button type="submit" class="btn btn-info m-b-xs" id="login-submit" tab-index="4" value="login" >Sign In</button>
                                
                            </div>
                              </form>
                              <div class="authent-reg">
                                  <p>Not registered? <a href="register.php">Create an account</a> or <br><a href="reset_1.html">Reset password</a> </p>
                              </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         
        
        <!-- Javascripts -->
        <?php include "includes/footer.php" ?>
    </body>
</html>