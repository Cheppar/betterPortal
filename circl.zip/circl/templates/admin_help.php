<?php include "../includes/init.php" ?>
<?php 
    if (logged_in()) {
        $username=$_SESSION['username'];
        if (!verify_user_group($pdo, $username, "XTLTS")) {
            set_msg("User '{$username}' does not have permission to view this page");
            redirect('../index.php');
        }
    } else {
        set_msg("Please log-in and try again");
        redirect('../index.php');
    } 
?>
 <!DOCTYPE html>
<html lang="en">
    <?php include "../includes/header.php" ?> 
    <body>
      <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
          <span class='sr-only'>Loading...</span>
        </div>
      </div>

        <div class="page-container">


          <div class="page-header">

          <!-- NAV START -->
            <?php include "../includes/nav.php" ?> 
         <!-- NAV END -->
            
        </div>

<!-- HEADER END -->

  <!-- SIDEBAR START -->
            
      <?php include "../includes/sidebar.php" ?> 

    <!-- SIDEBAR END -->

    <!-- PAGE CONTENT START -->

            <div class="page-content">
                <div class="main-wrapper">
                    <div class="row">

     <div class="row justify-content-md-center">
                <div class="col-md-12 col-lg-4">

                    <div class="card login-box-container">
                        <div class="card-body">

                    <?php show_msg(); ?>

                         <h1 class="text-center">Admin Help</h1>
            <p>"Page under development for the customer representative team"</p>

                            <!-- CONTENT HERE START-->

                            <!-- CONTENT HERE END-->
                              
                        </div>
                    </div>
                </div>
            </div>
                                  
                </div>

                <!-- PAGE CONTENT END -->
              
            </div>
        
        <!-- Javascripts -->
        <?php include "../includes/footer.php" ?> 
    </body>
</html>