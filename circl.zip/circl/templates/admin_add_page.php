<?php include("../includes/init.php");?>
<?php 
    if (logged_in()) {
        $username=$_SESSION['username'];
        if (!verify_user_group($pdo, $username, "XTLTS")) {
            set_msg("User '{$username}' does not have permission to view this page");
            redirect('../index.php');
        }
    } else {
        set_msg("Please log-in and try again");
        redirect('../index.php');
    } 
?>
<?php 
    if ($_SERVER['REQUEST_METHOD']=='POST') {
        $name=$_POST['name'];
        $descr=$_POST['descr'];
        $url=$_POST['url'];
        $group_id=$_POST['group_id'];
        
        if (strlen($name)<3) {
            $error[]="Group name must be at least 3 characters";
        }
        if (strlen($url)<3) {
            $error[]="URL must be at least 3 characters";
        }
        if (count_field_val($pdo,"groups", "id", $group_id)==0) {
            $error[]="Group ID not found in group table";
        }
        
        if (!isset($error)) {
            try {
                $stmnt=$pdo->prepare("INSERT INTO pages (name, descr, url, group_id) VALUES (:name, :descr, :url, :group_id)");
                $stmnt->execute([":name"=>$name, ":descr"=>$descr, ":url"=>$url, ":group_id"=>$group_id]);
                set_msg("Page '{$name}' as been added", "success");
                redirect("pages.php");
            } catch(PDOException $e){
                echo "Error: ".$e->getMessage();
            }
        }
    } else {
        $name="";
        $descr="";
        $url="";
        $group_id="";
    }
?>

<!DOCTYPE html>
<html lang="en">
    <?php include "../includes/header.php" ?> 
    <body>
      <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
          <span class='sr-only'>Loading...</span>
        </div>
      </div>

        <div class="page-container">


          <div class="page-header">

          <!-- NAV START -->
            <?php include "../includes/nav.php" ?> 
         <!-- NAV END -->
            
        </div>

<!-- HEADER END -->

  <!-- SIDEBAR START -->
            
      

    <!-- SIDEBAR END -->

    <!-- PAGE CONTENT START -->

            <div class="page-content">
                <div class="main-wrapper">
                    <div class="row">

     <div class="row justify-content-md-center">
                <div class="col-md-12 col-lg-4">

                    <div class="card login-box-container">
                        <div class="card-body">

                            <?php
                        if (isset($error)) {
                            foreach ($error as $msg) {
                                echo "<h4 class='bg-danger text-center'>{$msg}</h4>";
                            }
                        }
                    ?>
                            <div class="authent-logo">
                                <img src="../../assets/images/logo@2x.png" alt="">
                            </div>

                            <div class="authent-text">
                                <h2>Create Page</h2>
                                <p>Add a group when creating a page.</p>
                            </div>

                            <form id="register-form" method="post" role="form" >
                                        

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="text" name="name" id="name" tabindex="1" class="form-control" placeholder="Page Name" required value="<?php echo $name ?>">
                                        <label for="name">Page Name</label>
                                      </div>
                                </div>

                                        

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <input type="text" name="url" id="url" tabindex="2" class="form-control" placeholder="Page URL" required value="<?php echo $url ?>">
                                        <label for="url">Page URL</label>
                                      </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                        <select name='group_id' tabindex="3" id='group_id' class='form-control' required>
                                                <?php
                                                    try {
                                                        $result=$pdo->query("SELECT id, name FROM groups ORDER BY name");
                                                        foreach ($result as $row) {
                                                            echo "<option style='color:white;' value={$row['id']}>{$row['name']}</option>";
                                                        }
                                                    } catch(PDOException $e) {
                                                        echo "Error: ".$e->getMessage();
                                                    }
                                                ?>
                                            </select>
                                        <label for="group_id">Select Group</label>
                                      </div>
                                </div>

                                 <div class="mb-3">
                                    <div class="form-floating">
                                        <textarea name="descr" id="descr" tabindex="4" class="form-control" placeholder="Description - Tell us about your organization ?"><?php echo $descr ?></textarea>
                                        <label for="descr">Page Description</label>
                                      </div>
                                </div>



                                        <div class="d-grid">
                               <input type="submit" name="register-submit" tabindex="5" id="register-submit" tabindex="4" class="form-control btn btn-custom" value="Add Page">
                            </div>


                                    </form>
                              
                        </div>
                    </div>
                </div>
            </div>
                                  
                </div>

                <!-- PAGE CONTENT END -->
              
            </div>
        
        <!-- Javascripts -->
        <?php include "../includes/footer.php" ?> 
    </body>
</html>