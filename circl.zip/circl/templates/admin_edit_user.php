<?php include("../includes/init.php");?>
<?php
    // if (isset($_GET['id'])) {
    //     $user_id = $_GET['id'];
    //     if (count_field_val($pdo, "users", "id", $user_id)>0){
    //         $row=return_field_data($pdo, "users", "id", $user_id);
    //         $fname = $row['firstname'];
    //         $lname = $row['lastname'];
    //         $comments = $row['comments'];
    //     } else {
    //         redirect('admin.php');
    //     }
    // } else {
    //     redirect('admin.php');
    // }
?>
<?php 
    if (logged_in()) {
        $username=$_SESSION['username'];
        if (!verify_user_group($pdo, $username, "XTLTS")) {
            if ($username!=$row['username']) {
                set_msg("User '{$username}' does not have permission to view this page");
                redirect('../index.php');
            }
        }
    } else {
        set_msg("Please log-in and try again");
//        redirect('../index.php');
    } 
?>
<?php
    if ($_SERVER['REQUEST_METHOD']=="POST") {
        $fname = $_POST['firstname'];
        $lname = $_POST['lastname'];
        $comments = $_POST['comments'];
        
        if (strlen($lname)<3) {
            $error[] = "Last name must be at least 3 characters long";
        }
        
        if (!isset($error)) {
            try {
                $sql = "UPDATE users SET firstname=:firstname, lastname=:lastname, comments=:comments WHERE id=:id";
                $stmnt = $pdo->prepare($sql);
                $user_data = [':firstname'=>$fname, ':lastname'=>$lname, ':comments'=>$comments, ':id'=>$user_id];
                $stmnt->execute($user_data);
                redirect('admin.php');
            } catch(PDOException $e) {
                echo "Error: ".$e->getMessage();
            }
        }
        
    } 
?>

  <!DOCTYPE html>
<html lang="en">
    <?php include "../includes/header.php" ?> 
    <body>
      <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
          <span class='sr-only'>Loading...</span>
        </div>
      </div>

        <div class="page-container">


          <div class="page-header">

          <!-- NAV START -->
            <?php include "../includes/nav.php" ?> 
         <!-- NAV END -->
            
        </div>

<!-- HEADER END -->

  <!-- SIDEBAR START -->
            
      

    <!-- SIDEBAR END -->

    <!-- PAGE CONTENT START -->

            <div class="page-content">
                <div class="main-wrapper">
                    <div class="row">

     <div class="row justify-content-md-center">
                <div class="col-md-12 col-lg-4">

                    <div class="card login-box-container">
                        <div class="card-body">

                    <?php
                        if (isset($error)) {
                            foreach ($error as $msg) {
                                echo "<h4 class='bg-danger text-center'>{$msg}</h4>";
                            }
                        } ?>
                            <div class="authent-logo">
                                <img src="../../assets/images/logo@2x.png" alt="">
                            </div>

                            <div class="authent-text">
                                <h2>Edit User Info</h2>
                                <p>Change User Data.</p>
                            </div>

                            <form id="register-form" method="post" role="form">  
                                
                                <div class="mb-3">
                                    <div class="form-floating">
                                         <input type="text" name="firstname" id="firstname" tabindex="1" class="form-control" placeholder="First Name" value="<?php echo $fname ?>" required >
                                        <label for="firstname">Firstname</label>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                         <input type="text" name="lastname" id="lastname" tabindex="2" class="form-control" placeholder="Last Name" value="<?php echo $lname ?>" required >
                                        <label for="lastname">Lastname</label>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="form-floating">
                                          <textarea name="comments" id="comments" tabindex="7" class="form-control"  placeholder="Comments"><?php echo $comments ?></textarea>
                                        <label for="comments">Comments</label>
                                    </div>
                                </div>

                                

                                <div class="d-grid">
                                     <input type="submit" name="update-submit" id="update-submit" tabindex="4" class="form-control btn btn-success" value="Update User">
                                </div>

                            </form>
                              
                        </div>
                    </div>
                </div>
            </div>
                                  
                </div>

                <!-- PAGE CONTENT END -->
              
            </div>
        
        <!-- Javascripts -->
        <?php include "../includes/footer.php" ?> 
    </body>
</html>