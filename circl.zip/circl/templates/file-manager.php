
<?php include "../includes/init.php" ?>

<?php 
    if (logged_in()) {
        $username=$_SESSION['username'];
        if (!verify_user_group($pdo, $username, "XTLTS")) {
            set_msg("User '{$username}' does not have permission to view this page");
            redirect('../index.php');
        }
    } else {
        set_msg("Please log-in and try again");
        redirect('../index.php');
    } 
?>

  <!DOCTYPE html>
<html lang="en">
    <?php include "../includes/header.php" ?> 
    <body>
      <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
          <span class='sr-only'>Loading...</span>
        </div>
      </div>

        <div class="page-container">
          <div class="page-header">

          <!-- NAV START -->
            <?php include "../includes/nav.php" ?> 
         <!-- NAV END -->
            
        </div>

<!-- HEADER END -->

  <!-- SIDEBAR START -->
            
      <?php include "../includes/sidebar.php" ?> 

    <!-- SIDEBAR END -->

    <!-- PAGE CONTENT START -->

            <div class="page-content">
                <div class="main-wrapper">
                    <div class="row">

     <div class="row">
                  <div class="col-md-12 col-lg-12">

                      <div class="card table-widget">
                          <div class="card-body">

                            <?php 
                                    show_msg();
                                ?>
                              <h5 class="card-title">Registered Users</h5>


                              <div class="table-responsive">
                              <table class="table">

 <?php
                    try {
                        $result = $pdo->query("SELECT id, firstname, lastname, username, email, active, joined, last_login FROM users ORDER BY username");
                        if ($result->rowCount()>0) {
                            echo "<table class='table'>";
                            echo "<tr><th>ID</th><th>Firstname</th><th>Lastname</th><th>Username</th><th>Email</th><th>Active</th><th>Joined</th><th>Last Login</th></tr>";
                            foreach ($result as $row) {
                                if ($row['active']) {
                                    $active = "Yes";
                                    $action = "Deactivate";
                                } else {
                                    $active = "No";
                                    $action = "Activate";
                                }
                                echo "<tr><td>{$row['id']}</td><td>{$row['firstname']}</td><td>{$row['lastname']}</td><td>{$row['username']}</td><td>{$row['email']}</td><td>{$active}</td><td>{$row['joined']}</td><td>{$row['last_login']}</td><td><a href='admin_deactivate_user.php?id={$row['id']}'>{$action}</a></td><td><a href='admin_edit_user.php?id={$row['id']}'>Edit</a></td><td><a class='confirm-delete' href='admin_delete.php?id={$row['id']}&tbl=users'>Delete</a></td></tr>";
                            }
                            echo "</table>";
                        } else {
                            echo "No users in users table";
                        }
                    } catch(PDOException $e){
                        echo "Oops there was an error<br><br>".$e->getMessage();
                    }
                ?>
              
                            </div>
                          </div>
                      </div>
                  </div>
                  
                
                  
              </div>
                      
                      </div>
                                  
                </div>

                <!-- PAGE CONTENT END -->
              
            </div>
        
        <!-- Javascripts -->
        <?php include "../includes/footer.php" ?> 
    </body>
</html>